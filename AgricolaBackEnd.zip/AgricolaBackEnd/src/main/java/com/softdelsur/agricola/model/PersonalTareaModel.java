package com.softdelsur.agricola.model;

public class PersonalTareaModel {

}
