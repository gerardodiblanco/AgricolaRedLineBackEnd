package com.softdelsur.agricola.converter;

import java.util.List;

import org.springframework.stereotype.Component;

import com.softdelsur.agricola.entity.PersonalTarea;
import com.softdelsur.agricola.model.PersonalTareaModel;

@Component("personalTareaConverter")
public class PersonalTareaConverter {
	
	public PersonalTarea convertModelToEntity(PersonalTareaModel personalTareaModel){
		
	}
public PersonalTareaModel convertEntityToModel(PersonalTarea personalTarea){
		
	}
	
	public List<PersonalTarea> convertListModelToListEntity(List<PersonalTareaModel> personalTareaModelList){
		
		
	}
	
	public List<PersonalTareaModel> convertListEntityToListModel(List<PersonalTarea> personalTareaList){
		
		
	}

}
