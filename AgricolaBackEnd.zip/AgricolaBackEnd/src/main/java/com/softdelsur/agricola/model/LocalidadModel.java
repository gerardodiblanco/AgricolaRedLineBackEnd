package com.softdelsur.agricola.model;



public class LocalidadModel {
    private String idLocalidad;
   
   
private String nombre;

public LocalidadModel() {
	
}



public String getIdLocalidad() {
	return idLocalidad;
}

public void setIdLocalidad(String idLocalidad) {
	this.idLocalidad = idLocalidad;
}



public String getNombre() {
	return nombre;
}



public void setNombre(String nombre) {
	this.nombre = nombre;
}



}
