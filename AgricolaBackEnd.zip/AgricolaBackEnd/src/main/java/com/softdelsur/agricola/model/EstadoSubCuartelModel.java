package com.softdelsur.agricola.model;

public class EstadoSubCuartelModel {
    private String idEstado;
private int codigo;
private String descripcion;
public EstadoSubCuartelModel() {
	super();
}
public String getIdEstado() {
	return idEstado;
}
public void setIdEstado(String idEstado) {
	this.idEstado = idEstado;
}
public int getCodigo() {
	return codigo;
}
public void setCodigo(int codigo) {
	this.codigo = codigo;
}
public String getDescripcion() {
	return descripcion;
}
public void setDescripcion(String descripcion) {
	this.descripcion = descripcion;
}

}
