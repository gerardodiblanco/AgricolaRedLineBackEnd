package com.softdelsur.agricola.service;

import com.softdelsur.agricola.entity.Domicilio;
import com.softdelsur.agricola.model.DomicilioModel;

public interface DomicilioService {
	
	//DomicilioModel addDomicilioModel(DomicilioModel domicilioModel);
	
	Domicilio addDomicilio(Domicilio domicilio);

}
