package com.softdelsur.agricola.model;

public class ProveedorModelABMCampo {
	
	private String descripcion;

	private String razonSocial;
	
	public ProveedorModelABMCampo(){
		
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public String getRazonSocial() {
		return razonSocial;
	}

	public void setRazonSocial(String razonSocial) {
		this.razonSocial = razonSocial;
	}
	


	
	
}
