package com.softdelsur.agricola.model;

public class AtributoSubCuartelModel {

}
