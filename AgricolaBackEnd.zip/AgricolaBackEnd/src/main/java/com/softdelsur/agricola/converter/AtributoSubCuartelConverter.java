package com.softdelsur.agricola.converter;

import java.util.List;

import org.springframework.stereotype.Component;

import com.softdelsur.agricola.entity.AtributoSubCuartel;
import com.softdelsur.agricola.model.AtributoSubCuartelModel;

@Component("atributoSubCuartelConverter")
public class AtributoSubCuartelConverter {

	public List<AtributoSubCuartel> convertListAtributoSubCuartelModelToListAtributoSubCuartel(List<AtributoSubCuartelModel> atributoSubCuartelModelList){
		
	}
public List<AtributoSubCuartelModel> convertListAtributoSubCuartelToListAtributoSubCuartelModel(List<AtributoSubCuartel> atributoSubCuartelList){
		
	}
}
