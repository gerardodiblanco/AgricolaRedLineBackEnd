package com.softdelsur.agricola.model;

public class EstadoTareaDetalleSectorModel {

    private String id;

	private int codigo;
	private String descripcion;
	
	public EstadoTareaDetalleSectorModel() {
		super();
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public int getCodigo() {
		return codigo;
	}
	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}
	public String getDescripcion() {
		return descripcion;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	
	
}
