package com.softdelsur.agricola;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AgricolaApplication {

	public static void main(String[] args) {
		SpringApplication.run(AgricolaApplication.class, args);
	}
}
