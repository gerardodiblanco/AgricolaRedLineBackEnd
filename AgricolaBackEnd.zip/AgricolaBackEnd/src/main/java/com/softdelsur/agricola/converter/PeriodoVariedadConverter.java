package com.softdelsur.agricola.converter;

import java.util.List;

import org.springframework.stereotype.Component;

import com.softdelsur.agricola.entity.PeriodoVariedad;
import com.softdelsur.agricola.model.PeriodoVariedadModel;
@Component("periodoVariedadConverter")
public class PeriodoVariedadConverter {

	public List<PeriodoVariedad> convertListPeriodoVariedadModelToListPeriodoVariedad(List<PeriodoVariedadModel> periodoVariedadModelList){
		
	}
public List<PeriodoVariedadModel> convertListPeriodoVariedadToListPeriodoVariedadModel(List<PeriodoVariedad> periodoVariedadList){
		
	}
	
}
