package com.softdelsur.agricola.model;

public class UnidadMedidaModel {
	
    private String idUnidadMedida;
private String nombreUM;

public UnidadMedidaModel() {
	super();
}

public String getIdUnidadMedida() {
	return idUnidadMedida;
}

public void setIdUnidadMedida(String idUnidadMedida) {
	this.idUnidadMedida = idUnidadMedida;
}

public String getNombreUM() {
	return nombreUM;
}
public void setNombreUM(String nombreUM) {
	this.nombreUM = nombreUM;
}


}
