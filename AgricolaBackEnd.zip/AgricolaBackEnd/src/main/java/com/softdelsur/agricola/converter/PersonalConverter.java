package com.softdelsur.agricola.converter;

import org.springframework.stereotype.Component;

import com.softdelsur.agricola.entity.Personal;
import com.softdelsur.agricola.model.PersonalModel;

@Component("personalConverter")
public class PersonalConverter {

	public PersonalModel convertEntityToModel(Personal personal) {
		// TODO Auto-generated method stub
		return null;
	}

	public Personal convertModelToEntity(PersonalModel personal) {
		// TODO Auto-generated method stub
		return null;
	}

}
