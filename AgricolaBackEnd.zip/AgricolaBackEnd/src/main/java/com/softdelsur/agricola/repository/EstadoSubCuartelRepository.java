package com.softdelsur.agricola.repository;

import java.io.Serializable;

import org.springframework.data.jpa.repository.JpaRepository;

import com.softdelsur.agricola.entity.EstadoSubCuartel;

public interface EstadoSubCuartelRepository  extends JpaRepository<EstadoSubCuartel, Serializable>{

}
